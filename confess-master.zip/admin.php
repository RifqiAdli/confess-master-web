<?php
// Sertakan file koneksi
include 'koneksi.php';

// Handle pencarian
$search = isset($_GET['search']) ? $_GET['search'] : '';
$searchQuery = $search ? "WHERE username LIKE '%$search%'" : "";

// Ambil data confess
$confessions = $conn->query("SELECT * FROM confessions $searchQuery ORDER BY created_at DESC");

// Hapus confess
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM confessions WHERE id = $id");
    header("Location: admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Confess</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.js"></script>
</head>
<body class="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500">

    <div class="container mx-auto p-6 bg-white shadow-lg rounded-xl mt-6">
        <h1 class="text-4xl font-bold text-center mb-6 text-blue-600">Admin Panel</h1>

        <!-- Form Pencarian -->
        <form action="admin.php" method="GET" class="mb-6 flex justify-center items-center">
            <input type="text" name="search" placeholder="Cari berdasarkan nama..." value="<?= htmlspecialchars($search) ?>" 
                class="border p-2 w-1/2 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500">
            <button type="submit" class="bg-blue-500 text-white p-2 rounded-lg ml-4 hover:bg-blue-600 transition duration-300">Cari</button>
        </form>

        <!-- Daftar Confess -->
        <?php if ($confessions->num_rows > 0): ?>
            <table class="table-auto w-full bg-white shadow-lg rounded-lg">
                <thead>
                    <tr class="bg-blue-100">
                        <th class="p-4 text-left text-sm font-semibold text-gray-700">ID</th>
                        <th class="p-4 text-left text-sm font-semibold text-gray-700">Username</th>
                        <th class="p-4 text-left text-sm font-semibold text-gray-700">Confession</th>
                        <th class="p-4 text-left text-sm font-semibold text-gray-700">Spotify Link</th>
                        <th class="p-4 text-left text-sm font-semibold text-gray-700">Tanggal</th>
                        <th class="p-4 text-left text-sm font-semibold text-gray-700">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $confessions->fetch_assoc()): ?>
                    <tr class="border-t hover:bg-gray-50 transition duration-300">
                        <td class="p-4 text-sm"><?= $row['id'] ?></td>
                        <td class="p-4 text-sm"><?= htmlspecialchars($row['username']) ?></td>
                        <td class="p-4 text-sm"><?= htmlspecialchars($row['confession']) ?></td>
                        <td class="p-4 text-sm">
                            <?php if ($row['song_url']): ?>
                                <a href="<?= htmlspecialchars($row['song_url']) ?>" target="_blank" class="text-blue-500 hover:text-blue-700 transition duration-300">Spotify Link</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td class="p-4 text-sm"><?= $row['created_at'] ?></td>
                        <td class="p-4 text-sm">
                            <a href="edit.php?id=<?= $row['id'] ?>" class="text-yellow-500 hover:text-yellow-700 transition duration-300">Edit</a> |
                            <a href="admin.php?delete=<?= $row['id'] ?>" class="text-red-500 hover:text-red-700 transition duration-300" onclick="return confirm('Hapus confess ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center text-gray-500 text-xl mt-6">Tidak ada confess yang ditemukan.</p>
        <?php endif; ?>
    </div>

</body>
</html>
