<?php
include 'koneksi.php';

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$searchQuery = $search ? "WHERE username LIKE '%$search%'" : "";

// Batasi hanya 15 confession terbaru
$confessions = $conn->query("SELECT * FROM confessions $searchQuery ORDER BY created_at DESC LIMIT 15");

function containsProfanity($text) {
    // Daftar kata-kata kasar yang ingin diblokir
    $profanityList = [
        'anjing', 'babi', 'bangsat', 'bodoh', 'tolol', 'goblok', 'sialan', 
    'brengsek', 'bajingan', 'kontol', 'memek', 'ngentot', 'pepek', 
    'taik', 'bangke', 'keparat', 'asu', 'kampret', 'setan', 'iblis', 
    'jancuk', 'pantek', 'celeng', 'monyet', 'laknat', 'bencong', 
    'lonte', 'pelacur', 'parasit', 'sinting', 'gila', 'idiot', 
    'edun', 'anjrit', 'bacot', 'brengsek', 'cibai', 'pukimak', 
    'tapir', 'serigala', 'kacuk', 'mampus', 'bego', 'kerbau', 
    'balaga', 'brengkes', 'kapir', 'jembut', 'bengek', 'semprul', 'goblok', 'kntl', 'mmk', 'bawok', 'jmbt', 'titit', 'titid', 'tytyd', 'anjg', 'anj', 'goblok', 'gblk', 'asw', 'jnck', 'm3m3k', 'm3mek', 'k0nt0l', 'pantek', 'iclik', 'ndasmu', 'pntk', 'pekok', 'ngent','ngen',
    ];

    // Konversi teks ke lowercase untuk pencocokan
    $lowercaseText = strtolower($text);

    // Periksa setiap kata kasar
    foreach ($profanityList as $word) {
        if (strpos($lowercaseText, $word) !== false) {
            return true;
            
            
        }
    }

 
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username']);
    $confession = $conn->real_escape_string($_POST['confession']);
    $song_url = $conn->real_escape_string($_POST['song_url']);

    // Validasi server-side
    $errors = [];
    if (empty($username)) {
        $errors[] = "Nama tidak boleh kosong";
    }
    if (empty($confession)) {
        $errors[] = "Pesan Confess tidak boleh kosong";
    }
    if (strlen($username) < 3) {
        $errors[] = "Nama minimal 3 karakter";
    }
    if (strlen($confession) < 10) {
        $errors[] = "Pesan Confess minimal 10 karakter";
    }
// Tambahkan pengecekan kata kasar
    if (containsProfanity($username) || containsProfanity($confession)) {
        $errors[] = "Pesan Confess mengandung kata-kata yang tidak pantas. Mohon gunakan bahasa yang sopan.";
    }
    if (empty($errors)) {
        $query = "INSERT INTO confessions (username, confession, song_url) VALUES ('$username', '$confession', '$song_url')";
        if ($conn->query($query)) {
            header("Location: index.php?success=1");
            exit();
        } else {
            $errors[] = "Gagal menyimpan konfesi: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ConfessWorld - Share Your Feelings</title>
    
    <!-- Meta Tags -->
    <meta property="og:title" content="ConfessWorld - Share Your Feelings">
    <meta property="og:description" content="Platform anonim untuk berbagi perasaan">
    <meta property="og:image" content="https://app.confessworld.xyz/confessworld.png">
    <meta property="og:url" content="https://app.confessworld.xyz">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="https://app.confessworld.xyz/confessworld.png">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        /* Custom Styles */
        body {
            transition: background 0.3s, color 0.3s;
            background: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
        }
        
        body.dark {
            background: linear-gradient(135deg, #1a202c 0%, #2d3748 100%);
            color: #e2e8f0;
        }

        .card {
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
        }

        /* Dark Mode Specific Styles */
        body.dark .card {
            background-color: #2d3748;
            color: #e2e8f0;
        }

        body.dark input, 
        body.dark textarea {
            background-color: #4a5568;
            color: #e2e8f0;
            border-color: #718096;
        }
    </style>
</head>
<body class="min-h-screen <?= isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark' : '' ?>">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <!-- Dark Mode Toggle -->
        <div class="flex justify-end mb-4">
            <button id="darkModeToggle" class="bg-gray-800 text-white p-2 rounded-full">
                <i class="fas fa-moon"></i>
            </button>
        </div>

        <!-- Header -->
        <div class="text-center mb-12">
            <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
                <i class="fas fa-heart text-red-500 mr-3"></i>Confess World
            </h1>
            <p class="text-white text-lg opacity-80">Ungkapkan perasaanmu dengan aman dan nyaman secara anonim.</p>
        </div>

        <!-- Pesan Sukses -->
        <?php if(isset($_GET['success'])): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                Confess berhasil dikirim!
            </div>
        <?php endif; ?>

        <!-- Pencarian -->
        <div class="mb-8">
            <form action="index.php" method="GET" class="flex">
                <input type="text" name="search" 
                    placeholder="Cari Confess..." 
                    value="<?= htmlspecialchars($search) ?>" 
                    class="flex-grow px-4 py-3 rounded-l-lg border-2 border-r-0 focus:outline-none focus:ring-2">
                <button type="submit" class="bg-orange-500 text-white px-6 py-3 rounded-r-lg">
                    <i class="fas fa-search"></i>
                </button>
            </form>
        </div>

        <!-- Form Konfesi -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-8 mb-12">
            <h2 class="text-2xl font-bold mb-6 text-gray-800 dark:text-white">
                <i class="fas fa-comment-dots text-orange-500 mr-3"></i>Kirim Confess Baru
            </h2>

            <!-- Tampilkan Error -->
            <?php if(!empty($errors)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
                    <?php foreach($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <div class="grid gap-4">
                    <input type="text" name="username" required 
                        placeholder="Nama target confess" 
                        class="w-full px-4 py-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600">
                    
                    <textarea name="confession" required 
                        placeholder="Tulis pesan confessmu" 
                        rows="4" 
                        class="w-full px-4 py-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600"></textarea>
                    
                    <input type="url" name="song_url" 
                        placeholder="URL Spotify (Opsional)" 
                        class="w-full px-4 py-3 border rounded-lg dark:bg-gray-700 dark:border-gray-600">
                    
                    <button type="submit" class="bg-green-500 text-white px-6 py-3 rounde d-lg hover:bg-green-600 transition duration-300">
                        <i class="fas fa-paper-plane mr-2"></i>Kirim Confess
                    </button>
                </div>
            </form>
        </div>

        <!-- Daftar Konfesi -->
        <div>
            <h2 class="text-3xl font-bold mb-6 text-white">
                <i class="fas fa-stream text-red-500 mr-3"></i>Live Confess
            </h2>
            <div class="grid md:grid-cols-2 lg:grid-cols-2 gap-6">
                <?php while ($row = $confessions->fetch_assoc()): ?>
                <div class="card bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 transform hover:-translate-y-2 transition duration-300">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-user-circle text-orange-500 text-3xl mr-3"></i>
                        <h3 class="font-bold text-xl dark:text-white">Kepada: <?= htmlspecialchars($row['username']) ?></h3>
                    </div>
                    <p class="text-gray-700 dark:text-gray-300 mb-4"><?= nl2br(htmlspecialchars($row['confession'])) ?></p>
                    
                    <?php if (!empty($row['song_url'])): ?>
                        <?php if (strpos($row['song_url'], 'open.spotify.com/track') !== false): 
                            $embed_url = str_replace('open.spotify.com/track/', 'open.spotify.com/embed/track/', $row['song_url']); 
                        ?>
                            <iframe src="<?= htmlspecialchars($embed_url) ?>" 
                                    width="100%" height="80" frameborder="0" 
                                    allowtransparency="true" allow="encrypted-media" 
                                    class="rounded-lg mb-4"></iframe>
                        <?php else: ?>
                            <a href="<?= htmlspecialchars($row['song_url']) ?>" target="_blank" 
                                class="text-blue-500 dark:text-blue-400 hover:underline flex items-center">
                                <i class="fab fa-spotify mr-2"></i>Spotify Link
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <div class="text-sm text-gray-500 dark:text-gray-400 flex justify-between items-center">
                        <span><?= $row['created_at'] ?></span>
                        <i class="fas fa-heart text-red-400"></i>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-black bg-opacity-10 py-6 text-center text-white">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-4 md:mb-0">
                    <p class="text-sm">
                        &copy; <?= date('Y') ?> ConfessWorld. All Rights Reserved.
                    </p>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center">
                        <i class="fas fa-code mr-2"></i>
                        <span class="text-sm">Developed by</span>
                    </div>
                    <a href="#" class="hover:text-orange-300 transition duration-300 flex items-center">
                        <span class="font-semibold">AZL Teknologi Nusantara</span>
                    </a>
                </div>
                <div class="mt-4 md:mt-0">
                    <p class="text-xs opacity-70">
                        Version 0.5.2 - Beta
                    </p>
                </div>
            </div>
            <div class="mt-4 text-xs opacity-60">
                <p>
                    🛠️ Crafted with <i class="fas fa-heart text-red-400 mx-1"></i> 
                    using PHP, Tailwind CSS, and ❤️ Passion
                </p>
            </div>
        </div>
    </footer>

    <script>
       document.addEventListener('DOMContentLoaded', function() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    const body = document.body;

    // Cek tema saat halaman dimuat
    function checkTheme() {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            body.classList.add('dark');
        }
    }

    // Fungsi untuk mengubah tema
    function toggleDarkMode() {
        body.classList.toggle('dark');
        
        // Simpan ke localStorage
        if (body.classList.contains('dark')) {
            localStorage.setItem('theme', 'dark');
        } else {
            localStorage.setItem('theme', 'light');
        }
    }

    // Panggil fungsi cek tema saat halaman dimuat
    checkTheme();

    // Event listener untuk tombol dark mode
    darkModeToggle.addEventListener('click', toggleDarkMode);
});
    </script>
</body>
</html>