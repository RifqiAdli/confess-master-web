<?php
// Koneksi database
include 'koneksi.php';

// Ambil data confess berdasarkan ID
$id = intval($_GET['id']);
$result = $conn->query("SELECT * FROM confessions WHERE id = $id");
$confess = $result->fetch_assoc();

// Update confess
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $confession = $_POST['confession'];
    $song_url = $_POST['song_url'];

    $stmt = $conn->prepare("UPDATE confessions SET username = ?, confession = ?, song_url = ? WHERE id = ?");
    $stmt->bind_param("sssi", $username, $confession, $song_url, $id);
    $stmt->execute();

    header("Location: admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Confess</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-4">
        <h1 class="text-3xl font-bold mb-4">Edit Confess</h1>
        <form action="" method="POST" class="bg-white shadow p-4 rounded">
            <div class="mb-4">
                <label class="block font-bold">Username:</label>
                <input type="text" name="username" value="<?= htmlspecialchars($confess['username']) ?>" class="border p-2 w-full" required>
            </div>
            <div class="mb-4">
                <label class="block font-bold">Confession:</label>
                <textarea name="confession" class="border p-2 w-full" required><?= htmlspecialchars($confess['confession']) ?></textarea>
            </div>
            <div class="mb-4">
                <label class="block font-bold">Spotify Song URL:</label>
                <input type="url" name="song_url" value="<?= htmlspecialchars($confess['song_url']) ?>" class="border p-2 w-full">
            </div>
            <button type="submit" class="bg-blue-500 text-white p-2 rounded">Simpan</button>
        </form>
    </div>
</body>
</html>
