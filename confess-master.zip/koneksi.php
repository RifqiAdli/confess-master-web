<?php
// File koneksi.php
$host = "localhost";
$user = "dqbxwbqn_user_confess";
$pass = "webconfess2024jaya";
$dbname = "dqbxwbqn_user_confess";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}
?>
